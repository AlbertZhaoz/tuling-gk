Use this space to describe what this pull request accomplishes. 

Refer to open issues by their number to help link them with this pull request.

Consider including screenshots or code samples if it would help communicate the purpose of this pull request.

```cs
ScottPlot.Plot myPlot = new();
/* a code sample may improve communication */
myPlot.SavePng("bug.png");
```