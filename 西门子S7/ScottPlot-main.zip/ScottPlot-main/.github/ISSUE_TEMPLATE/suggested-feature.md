---
name: Suggestion
about: Have an idea for improving ScottPlot? Create a GitHib issue to share your thoughts!
title: ''
labels: ''
assignees: ''
---

**Suggestion:** (Describe your idea here)

```cs
ScottPlot.Plot myPlot = new();
/* a code sample may improve communication */
myPlot.SavePng("bug.png");
```