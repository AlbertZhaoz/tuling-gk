ScottPlot welcomes contributions from the open source community! 🚀

See http://scottplot.net/contributing/ for more information and suggestions for first time contributors.