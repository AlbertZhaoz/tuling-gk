﻿namespace ScottPlot.Cookbook;

public interface ICategory
{
    public string Name { get; }
    public string Description { get; }
    public string Folder { get; }
}
