﻿using Eto.Forms;
using Eto.Drawing;

namespace ScottPlot.Eto
{
    partial class PlotViewForm : Form
    {
        void InitializeComponent()
        {
            MinimumSize = new Size(200, 200);
        }
    }
}
